import {
  MatDivider,
  MatDividerModule
} from "./chunk-CNJNKLGC.js";
import "./chunk-DUHC7A74.js";
import "./chunk-2TDYIDKU.js";
import "./chunk-NTV2XCQV.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
